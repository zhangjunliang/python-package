# -*- coding: utf-8 -*-


def test():
    print('demo:hello world')


if __name__ == '__main__':
    test()
